'use strict';
/* CLIENT - the Map: the land around you, drawn from the terrain function (no chunks are generated for it), with you, your home,
 * stables, your ponies and the X of any treasure map you have read. World north is up.
 *   NEAR  65 tiles across, 4 px per tile: every tree, your ponies, stables.
 *   FAR   260 tiles across, 1 px per tile: the BIOMES, and rings at every 100 tiles out from the village marked with how strong the
 *         animals get there (levels SCALE FROM THE ORIGIN: the farther out, the higher the level and the rarer the ponies). */
const TOWN = Waypoints.TOWN;          // the village square: the map always points the way back
const AREA_MAP_RADIUS = 32, AREA_MAP_LAYER_RADIUS = 58, AREA_MAP_PX = 4;
/** The map is turned 45 degrees to match the isometric view of the world (world +x runs down-right on screen, +y down-left). */
/** The map uses the SAME 2:1 isometric projection as the world: a world step (dx, dy) lands at ((dx - dy) * K1, (dx + dy) * K2) with K2 = K1 / 2, so shapes, directions and distances read exactly like the game. */
const MAP_K1_NEAR = 1.0, MAP_K1_FAR = 1.3;
const FAR_MAP_SPAN = 640, FAR_MAP_LAYER = 1000, FAR_MAP_STEP = 4, FAR_RING_EVERY = 250;       // the far view shows 640 tiles; its terrain image is a little bigger so you can wander before it is remade
const AREA_COLORS = { [TILE.GRASS]: '#6aa84f', [TILE.DIRT]: '#a98258', [TILE.STONE]: '#a9a59c', [TILE.WATER]: '#2c6b99', [TILE.SAND]: '#dccb94', [TILE.CLAY]: '#b8734a', [TILE.SHALLOW]: '#7bc3dc' };
/** Map colours for grass / dirt by biome (a little stronger than the ground so a biome reads at a glance). */
const BIOME_MAP_COLORS = Object.fromEntries(Biomes.all().map(b => [b.id, b.mapColor]));      // (from the biome table)

class MapUI {
  /** A little compass: a disc with N, and a tick pointing the way north really goes on screen (world -y = up and to the right). */
  static compass(ctx, cx, cy, K1, K2) {
    const dx = K1, dy = -K2, len = Math.hypot(dx, dy), ux = dx / len, uy = dy / len;
    ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.82)'; ctx.strokeStyle = 'rgba(70,45,20,.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(cx, cy, 11, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.moveTo(cx + ux * 13, cy + uy * 13); ctx.lineTo(cx + ux * 6 - uy * 3.5, cy + uy * 6 + ux * 3.5); ctx.lineTo(cx + ux * 6 + uy * 3.5, cy + uy * 6 - ux * 3.5); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(40,25,10,.95)'; ctx.font = 'bold 11px Georgia'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('N', cx - ux * 2.5, cy - uy * 2.5 + 0.5); ctx.restore();
  }

  constructor({ panel, body, closeButton, game, onTreasure, prefs }) {
    this.prefs = prefs; this.panel = panel; this.body = body; this.game = game; this.onTreasure = onTreasure; this.layer = null; this.farLayer = null; this.sinceDraw = 1e9; this.canvas = null; this.zoom = 'near';
    this.pan = { x: 0, y: 0 }; this.drag = null; this.frame = 0;                 // dragging the map moves the view away from you (Centre on me brings it back)
    closeButton.addEventListener('click', () => this.close());
  }
  get isOpen() { return !this.panel.hidden; }
  open() {
    this.panel.hidden = false; const size = (2 * AREA_MAP_RADIUS + 1) * AREA_MAP_PX;
    this.body.innerHTML = `<div class="mapcontent"><div class="mapwrap"><canvas id="areaMap" width="${size}" height="${size}"></canvas></div><div class="mapside">` +
      '<div class="mapzoom"><button id="zoomNear">Near</button><button id="zoomFar">Far</button><button id="mapCentre" title="Drag the map to look around; this brings it back to you">Centre on me</button></div>' +
      '<div class="maplegend"><span class="you">\u25CF you</span><span class="pet">\u25CF ponies</span><span class="home">\u2302 home</span><span class="stb">\u25A0 stable</span><span class="x">\u2716 treasure</span><span class="town">\u27A4 town</span><span class="cub">\u{1F43E} lost cub</span><span class="qst">\u2757 quest</span></div>' +
      '<div class="mapway" id="mapWay"><b>Waypoints on screen</b>' + [['quest', 'wq', '\u2757 Quests'], ['interest', 'wi', '\u2716 Things of interest'], ['home', 'wh', '\u2302 Home']].map(([g, c, t]) => `<label class="${c}"><input type="checkbox" data-way="${g}"${this.prefs && this.prefs.on[g] ? ' checked' : ''}> ${t}</label>`).join('') + '</div>' +
      '<div class="biomekey" id="biomeKey"></div>' +
      '<div class="mapinfo" id="areaInfo"></div><div class="mapnav"><button id="areaTreasure">Treasure maps</button></div></div></div>';
    this.canvas = this.body.querySelector('#areaMap');
    const t = this.body.querySelector('#areaTreasure'); if (t) t.addEventListener('click', () => this.onTreasure());
    const near = this.body.querySelector('#zoomNear'), far = this.body.querySelector('#zoomFar');
    if (near) near.addEventListener('click', () => this.setZoom('near')); if (far) far.addEventListener('click', () => this.setZoom('far'));
    for (const box of this.body.querySelectorAll('input[data-way]')) box.addEventListener('change', () => { if (this.prefs) this.prefs.set(box.dataset.way, box.checked); });      // (the game then draws a line to each place on screen: waypointOverlay.js)
    const centre = this.body.querySelector('#mapCentre'); if (centre) centre.addEventListener('click', () => { this.pan = { x: 0, y: 0 }; this.draw(); });
    this.pan = { x: 0, y: 0 }; this._bindDrag(this.canvas);
    this.setZoom(this.zoom);
  }
  close() { this.panel.hidden = true; this.canvas = null; this.drag = null; }

  /** Drag (mouse or finger) to look around the map. The map is isometric, so a drag on screen is turned back into a step in the world. */
  _bindDrag(canvas) {
    if (!canvas || !canvas.addEventListener) return;
    canvas.style.touchAction = 'none'; canvas.style.cursor = 'grab';
    canvas.addEventListener('pointerdown', e => { e.preventDefault(); canvas.setPointerCapture(e.pointerId); this.drag = { id: e.pointerId, x: e.clientX, y: e.clientY, pan: Object.assign({}, this.pan) }; canvas.style.cursor = 'grabbing'; });
    canvas.addEventListener('pointermove', e => {
      const d = this.drag; if (!d || d.id !== e.pointerId || !this.canvas) return;
      const rect = canvas.getBoundingClientRect(), k = canvas.width / (rect.width || 1), far = this.zoom === 'far';
      const px = far ? canvas.width / FAR_MAP_SPAN : canvas.width / (2 * AREA_MAP_RADIUS + 1), K1 = far ? MAP_K1_FAR : MAP_K1_NEAR, K2 = K1 / 2;
      const a = (e.clientX - d.x) * k / (px * K1), b = (e.clientY - d.y) * k / (px * K2);   // screen = ((dx - dy) K1, (dx + dy) K2) * px, so...
      this.pan = { x: d.pan.x - (a + b) / 2, y: d.pan.y - (b - a) / 2 };
      if (!this.frame) this.frame = requestAnimationFrame(() => { this.frame = 0; this.draw(); });
    });
    const end = e => { if (this.drag && this.drag.id === e.pointerId) { this.drag = null; canvas.style.cursor = 'grab'; } };
    canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
  }
  /** Move the view by this many screen pixels (a stick instead of a drag: right looks further right on the map). */
  panView(dx, dy) {
    const canvas = this.canvas; if (!canvas || !this.isOpen) return;
    const rect = canvas.getBoundingClientRect(), k = canvas.width / (rect.width || 1), far = this.zoom === 'far';
    const px = far ? canvas.width / FAR_MAP_SPAN : canvas.width / (2 * AREA_MAP_RADIUS + 1), K1 = far ? MAP_K1_FAR : MAP_K1_NEAR, K2 = K1 / 2;
    const a = dx * k / (px * K1), b = dy * k / (px * K2);
    this.pan = { x: this.pan.x + (a + b) / 2, y: this.pan.y + (b - a) / 2 };
    if (!this.frame) this.frame = requestAnimationFrame(() => { this.frame = 0; this.draw(); });
  }
  /** An arrow on the edge of the map pointing at something off it, with a label. */
  static edgeArrow(ctx, mid, x, y, color, label) {
    const a = Math.atan2(y - mid, x - mid), r = mid - 12, ax = mid + Math.cos(a) * r, ay = mid + Math.sin(a) * r;
    ctx.save(); ctx.translate(ax, ay); ctx.rotate(a); ctx.fillStyle = color; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(-6, -8); ctx.lineTo(-2, 0); ctx.lineTo(-6, 8); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
    if (!label) return;
    ctx.font = 'bold 10px Georgia'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const lx = ax - Math.cos(a) * 20, ly = ay - Math.sin(a) * 16, w = ctx.measureText(label).width + 8;
    ctx.fillStyle = 'rgba(10,20,30,.8)'; ctx.fillRect(lx - w / 2, ly - 7, w, 14); ctx.fillStyle = '#fff'; ctx.fillText(label, lx, ly + 0.5);
  }
  setZoom(zoom) {
    this.zoom = zoom; this.sinceDraw = 1e9;
    for (const [id, z] of [['#zoomNear', 'near'], ['#zoomFar', 'far']]) { const b = this.body.querySelector(id); if (b && b.classList) b.classList.toggle('on', z === zoom); }
    const key = this.body.querySelector('#biomeKey');
    if (key) key.innerHTML = zoom === 'far' ? Biomes.where(b => !b.terrainOnly).map(b => `<span style="--c:${BIOME_MAP_COLORS[b.id]}">${b.name} <small>${b.rarity}</small></span>`).join('') : '';
    this.draw();
  }
  tick(frameMs) { if (this.isOpen && (this.sinceDraw += frameMs) > 250) { this.sinceDraw = 0; this.draw(); } }

  /** Terrain colour of a tile, tinted by biome. */
  _color(T, tx, ty) {
    const tile = T.tile(tx, ty);
    if (tile === TILE.GRASS || tile === TILE.DIRT) return BIOME_MAP_COLORS[T.biomeAt(tx, ty, tile)] || AREA_COLORS[tile];
    return AREA_COLORS[tile] || '#6aa84f';
  }

  /** A big terrain image around a centre, re-made only when you wander far from where it was made. */
  _terrain(cx, cy) {
    if (this.layer && Math.hypot(this.layer.cx - cx, this.layer.cy - cy) < 5) return this.layer;
    const R = AREA_MAP_LAYER_RADIUS, px = AREA_MAP_PX, size = (2 * R + 1) * px, canvas = document.createElement('canvas');
    canvas.width = canvas.height = size;
    const ctx = canvas.getContext('2d'), T = this.game.worldMap.terrain, fx = Math.floor(cx), fy = Math.floor(cy);
    for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) {
      const tx = fx + dx, ty = fy + dy, tile = T.tile(tx, ty), x = (dx + R) * px, y = (dy + R) * px;
      ctx.fillStyle = this._color(T, tx, ty); ctx.fillRect(x, y, px, px);
      if (tile === TILE.GRASS && T.hasTree(tx, ty, tile)) { ctx.fillStyle = 'rgba(20,60,25,.55)'; ctx.fillRect(x + 1, y + 1, px - 2, px - 2); }
    }
    return (this.layer = { canvas, cx: fx + 0.5, cy: fy + 0.5 });
  }

  /** The zoomed-out terrain: every 4th tile, 1 px each, remade when you have moved 50 tiles. */
  _farTerrain(cx, cy) {
    const locks = this.game.worldMap.layers.rings.unlockedList().join();
    if (this.farLayer && this.farLayer.locks === locks && Math.hypot(this.farLayer.cx - cx, this.farLayer.cy - cy) < 50) return this.farLayer;
    const half = FAR_MAP_LAYER / 2, canvas = document.createElement('canvas');
    canvas.width = canvas.height = FAR_MAP_LAYER;
    const ctx = canvas.getContext('2d'), T = this.game.worldMap.terrain, rings = this.game.worldMap.layers.rings, fx = Math.floor(cx), fy = Math.floor(cy), S = FAR_MAP_STEP;
    for (let dy = -half; dy < half; dy += FAR_MAP_STEP) for (let dx = -half; dx < half; dx += FAR_MAP_STEP) {
      const x = fx + dx, y = fy + dy, ring = rings.at(x, y).index;
      ctx.fillStyle = this._color(T, x, y); ctx.fillRect(dx + half, dy + half, S, S);
      if (!rings.isUnlocked(ring)) { ctx.fillStyle = 'rgba(30,12,60,.38)'; ctx.fillRect(dx + half, dy + half, S, S); }                 // a sealed ring is dimmed
      if (rings.at(x + S, y).index !== ring || rings.at(x, y + S).index !== ring) { ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillRect(dx + half, dy + half, S, S); }   // the (imperfect) edge between two rings
    }
    return (this.farLayer = { canvas, cx: fx + 0.5, cy: fy + 0.5, locks });
  }

  draw() {
    const canvas = this.canvas; if (!canvas) return;
    const g = this.game, me = g.grid ? Object.assign({}, g.local, g.outsidePosition()) : g.local, ctx = canvas.getContext('2d'), size = canvas.width, mid = size / 2, far = this.zoom === 'far';
    const view = { x: me.x + this.pan.x, y: me.y + this.pan.y };                     // where the map is looking (dragged away from you, or on you)
    const px = far ? size / FAR_MAP_SPAN : size / (2 * AREA_MAP_RADIUS + 1), span = far ? FAR_MAP_SPAN / 2 : AREA_MAP_RADIUS;
    ctx.fillStyle = '#2c6b99'; ctx.fillRect(0, 0, size, size);
    /* The world is drawn ISOMETRICALLY (turned 45 degrees), so the map is turned the same way: what is up-screen in the game is up-map here, and walking
     * down-right in the game moves you down-right on the map. Terrain is drawn in a rotated frame; text and icons are placed with toMap() and stay upright. */
    const K1 = far ? MAP_K1_FAR : MAP_K1_NEAR, K2 = K1 / 2;
    ctx.save(); ctx.translate(mid, mid); ctx.transform(K1, K2, -K1, K2, 0, 0);
    if (far) {
      const layer = this._farTerrain(view.x, view.y); ctx.scale(px, px);
      ctx.drawImage(layer.canvas, -(view.x - layer.cx + 0.5 + FAR_MAP_LAYER / 2), -(view.y - layer.cy + 0.5 + FAR_MAP_LAYER / 2));
    } else {
      const layer = this._terrain(view.x, view.y), L = AREA_MAP_LAYER_RADIUS;
      ctx.drawImage(layer.canvas, -((view.x - layer.cx + L + 0.5) * px), -((view.y - layer.cy + L + 0.5) * px));
    }
    ctx.restore();
    const toMap = (wx, wy) => { const dx = (wx - view.x) * px, dy = (wy - view.y) * px; return [mid + (dx - dy) * K1, mid + (dx + dy) * K2]; }, inside = (x, y) => x > 3 && y > 3 && x < size - 3 && y < size - 3;
    ctx.strokeStyle = 'rgba(70,45,20,.9)'; ctx.lineWidth = 3; ctx.strokeRect(1.5, 1.5, size - 3, size - 3);

    const O = CONFIG.sim.levels.origin, [ox, oy] = toMap(O.x, O.y);                                          // the origin, and (far) rings of rising level round it
    if (far) {
      ctx.font = 'bold 10px Georgia'; ctx.textAlign = 'left';
      const rings = g.worldMap.layers.rings;
      for (const def of Zones.all()) {                                                                         // name each zone over its middle
        const c = rings.centreOf(def.index), locked = !rings.isUnlocked(def.index), txt = `${locked ? '\u{1F512} ' : ''}${def.name}  Lv ${def.levelMin}-${def.levelMax}`;
        const [lx, ly] = toMap(def.index ? c.x : O.x + 40, def.index ? c.y : O.y + 70);
        if (lx < 30 || ly < 26 || lx > size - 150 || ly > size - 14) continue;
        ctx.fillStyle = 'rgba(10,20,30,.78)'; ctx.fillRect(lx - 3, ly - 9, ctx.measureText(txt).width + 8, 13); ctx.fillStyle = def.color; ctx.fillText(txt, lx + 1, ly + 1);
      }
    }
    if (inside(ox, oy)) { ctx.fillStyle = '#ffe9a8'; ctx.strokeStyle = '#6b3d1c'; ctx.lineWidth = 1.4; ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 3 : 7; ctx.lineTo(ox + Math.cos(a) * r, oy + Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.stroke(); }

    if (!far) {
      const H = Village.home, [hx, hy] = toMap((H.x0 + H.x1 + 1) / 2, (H.y0 + H.y1 + 1) / 2);                       // home
      if (inside(hx, hy)) { ctx.fillStyle = '#fff'; ctx.strokeStyle = '#6b3d1c'; ctx.lineWidth = 1.6; ctx.fillRect(hx - 5, hy - 2, 10, 7); ctx.strokeRect(hx - 5, hy - 2, 10, 7); ctx.fillStyle = '#b5482f'; ctx.beginPath(); ctx.moveTo(hx - 7, hy - 2); ctx.lineTo(hx, hy - 9); ctx.lineTo(hx + 7, hy - 2); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      for (const key in g.worldMap.built) {                                                                               // stables
        const tile = g.worldMap.built[key]; if (!tile || (tile.c !== 'stable' && tile.c !== 'barn')) continue;
        const [x, y] = toMap(keyTileX(key) + 0.5, keyTileY(key) + 0.5); if (!inside(x, y)) continue;
        ctx.fillStyle = '#8a5a2c'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6; ctx.fillRect(x - 4, y - 4, 8, 8); ctx.strokeRect(x - 4, y - 4, 8, 8);
      }
    }
    for (const pet of g.pets) {                                                                                       // your ponies (and ones you are gentling)
      const [x, y] = toMap(pet.x, pet.y); if (!inside(x, y)) continue;
      ctx.fillStyle = pet.gentling ? '#ffd24a' : (PONY_KIND_COLORS[pet.type] || '#f48fb1'); ctx.strokeStyle = '#1b2a3a'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, far ? 2.4 : 3.8, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    }
    let nearest = null;
    for (const m of g.treasureMaps) {                                                                                 // treasure
      const wx = m.tx + 0.5, wy = m.ty + 0.5, d = Math.hypot(wx - me.x, wy - me.y); if (!nearest || d < nearest.d) nearest = { d, wx, wy };
      const [x, y] = toMap(wx, wy); if (!inside(x, y)) continue;
      if (m.kind === 'dungeon') { const rr = far ? 4 : 6; ctx.fillStyle = '#3a1f5a'; ctx.strokeStyle = '#e8d0ff'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y, rr, Math.PI, 0); ctx.lineTo(x + rr, y + rr * 0.8); ctx.lineTo(x - rr, y + rr * 0.8); ctx.closePath(); ctx.fill(); ctx.stroke(); continue; }          // a cave mouth
      const k = far ? 4 : 6; ctx.strokeStyle = '#c0392b'; ctx.lineWidth = far ? 2.4 : 3; ctx.beginPath(); ctx.moveTo(x - k, y - k); ctx.lineTo(x + k, y + k); ctx.moveTo(x + k, y - k); ctx.lineTo(x - k, y + k); ctx.stroke();
    }
    const nm = nearest && toMap(nearest.wx, nearest.wy);
    if (nearest && !inside(nm[0], nm[1])) MapUI.edgeArrow(ctx, mid, nm[0], nm[1], '#c0392b', '');                         // off the map: an arrow on the border
    let cub = null;
    for (const c of g.questMarks || []) {                                                                             // lost young you have tracked (paw prints in the cave)
      const d = Math.hypot(c.x - me.x, c.y - me.y); if (!cub || d < cub.d) cub = { d, x: c.x, y: c.y };
      const [x, y] = toMap(c.x + 0.5, c.y + 0.5); if (!inside(x, y)) continue;
      const r = far ? 5 : 7; ctx.fillStyle = c.kind === 'fed' ? '#ffe08a' : '#8a5a35'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.2, r * 0.36, r * 0.28, 0, 0, Math.PI * 2); ctx.fill();
      for (let t = 0; t < 3; t++) { ctx.beginPath(); ctx.arc(x - r * 0.4 + t * r * 0.4, y - r * 0.32, r * 0.16, 0, Math.PI * 2); ctx.fill(); }
    }
    const cm = cub && toMap(cub.x + 0.5, cub.y + 0.5);
    if (cub && !inside(cm[0], cm[1])) MapUI.edgeArrow(ctx, mid, cm[0], cm[1], '#8a5a35', `Cub ${Math.round(cub.d)}`);
    for (const wp of Waypoints.collect(g).filter(w => w.group === 'quest')) {                                           // where each quest under way points: a gold pin with its step
      const [x, y] = toMap(wp.x, wp.y);
      if (!inside(x, y)) { MapUI.edgeArrow(ctx, mid, x, y, wp.color, `${wp.label} ${Math.round(Math.hypot(wp.x - me.x, wp.y - me.y))}`); continue; }
      const r = far ? 6 : 8; ctx.fillStyle = wp.color; ctx.strokeStyle = '#3a2a08'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(x, y - r, r, Math.PI * 0.8, Math.PI * 0.2 + Math.PI * 2); ctx.lineTo(x, y + 1); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#3a2a08'; ctx.font = 'bold 11px Georgia'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(wp.glyph, x, y - r + 0.5);
      if (!far) { ctx.font = 'bold 10px Georgia'; const w = ctx.measureText(wp.label).width + 8; ctx.fillStyle = 'rgba(10,20,30,.8)'; ctx.fillRect(x - w / 2, y - 2 * r - 15, w, 13); ctx.fillStyle = wp.color; ctx.fillText(wp.label, x, y - 2 * r - 8); }
    }
    const [tx, ty] = toMap(TOWN.x, TOWN.y);                                                                             // the way back to town: always
    if (inside(tx, ty)) {
      ctx.font = 'bold 10px Georgia'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; const w = ctx.measureText(TOWN.name).width + 8;
      ctx.fillStyle = 'rgba(10,20,30,.8)'; ctx.fillRect(tx - w / 2, ty - 22, w, 13); ctx.fillStyle = '#ffe9a8'; ctx.fillText(TOWN.name, tx, ty - 15);
    } else MapUI.edgeArrow(ctx, mid, tx, ty, '#e3a92b', `${TOWN.name} ${Math.round(Math.hypot(TOWN.x - me.x, TOWN.y - me.y))}`);
    const [mx, my] = toMap(me.x, me.y);
    if (inside(mx, my)) {
      const fx = Math.cos(me.facing), fy = Math.sin(me.facing);
      ctx.save(); ctx.translate(mx, my); ctx.rotate(Math.atan2((fx + fy) * K2, (fx - fy) * K1));                                  // you, pointing the way the world points
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#1b3d73'; ctx.lineWidth = 2; const k = far ? 0.7 : 1; ctx.beginPath(); ctx.moveTo(8 * k, 0); ctx.lineTo(-5 * k, -5.5 * k); ctx.lineTo(-2.5 * k, 0); ctx.lineTo(-5 * k, 5.5 * k); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
    } else MapUI.edgeArrow(ctx, mid, mx, my, '#2f6fd0', 'You');
    MapUI.compass(ctx, size - 24, 24, K1, K2);                                                                          // north is up-right in an isometric view

    const info = this.body.querySelector('#areaInfo');
    if (info) {
      const dist = AnimalLevels.distance(me.x, me.y), zone = AnimalLevels.zoneLevel(me.x, me.y, g.worldMap.layers), biome = isWaterTile(g.worldMap.tile(Math.floor(me.x), Math.floor(me.y))) ? 'Open water' : (BiomeNames[g.worldMap.biome(Math.floor(me.x), Math.floor(me.y))] || '');
      const rings = g.worldMap.layers.rings, ring = rings.def(rings.at(me.x, me.y).index);
      info.innerHTML = `<b>${biome}</b> &middot; ${Math.round(dist)} tiles from the village<br><span style="color:${ring.color}">${ring.name}</span> &middot; wild things here are about <b>level ${zone}</b>${rings.isUnlocked(ring.index) ? '' : ' &middot; \u{1F512} sealed until its guardian falls'}` +
        (nearest ? `<br>Nearest treasure X: about ${Math.round(nearest.d)} tiles away.` : '');
    }
  }
}
