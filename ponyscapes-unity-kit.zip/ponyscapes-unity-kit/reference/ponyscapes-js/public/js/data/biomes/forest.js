'use strict';
/* DATA - biome: forest */
Biomes.register({ id: 'forest', levels: [5, 10], name: 'Forest', rarity: 'uncommon', from: 0.7, mapColor: '#3f7f3f', ponyVariant: 'moss', effect: null,
  cliff: { base: '#6d7766', moss: '#3f6b3a', mossLight: '#5c8a48', grass: ['#4f8a42', '#57944a', '#497f3d'] },
  ground: { grass: ['#4f8a42', '#57944a', '#497f3d'], dirt: ['#8e6e4a', '#977650', '#866646'] },
  bush: 0.04, stone: 0.008, flax: 0.012, berries: [['blackberry', 7], ['blueberry', 3]], appleTrees: 0.12, treeBoost: 0.14 });
