'use strict';
/* DATA - the pony kinds. baseSpeed: tiles / second at full gallop at level 1 (the level curve in CONFIG.sim.ponySpeed scales it);
 * lassoTier: the lasso it takes to catch one (1 = the plain rope lasso; see the lassos in data/items/tools.js).
 * lassoNeeds: (late game) the themed lasso(es) a kind demands on top of its tier: a Water Pony only yields to a Water Lasso, a Star Pony to Harmony. The Rainbow Lasso opens every one (ItemDB.lassoHolds).
 * tameTier: how exotic a fruit it takes to gentle one (0 = a plain apple ... see AnimalLevels.tameFruit; higher LEVELS climb the same ladder), tameApples: how many.
 * DATA - the pony kinds. Which ring each lives in, how common it is and how big a herd; the rest (shy, protected, lured by food, tameable with a lasso)
 * is the common pony behaviour applied by the animal factory. Add a pony = add a line (and its look in the variants table if it needs one). */
PonyKinds.register({ id: 'pony_plain', name: 'Pony', baseSpeed: 3.8, lassoTier: 1, ring: 0, weight: 2.5, group: [1, 3], levelBase: 1, tameApples: 2, tameTier: 0 });
PonyKinds.register({ id: 'pony_earth', name: 'Earth Pony', baseSpeed: 4.4, lassoTier: 1, ring: 1, weight: 3, group: [1, 3], levelBase: 6, tameApples: 2, tameTier: 1 });
PonyKinds.register({ id: 'pony_pegasus', name: 'Pegasus', baseSpeed: 5.2, lassoTier: 2, ring: 2, weight: 2, group: [1, 2], levelBase: 11, tameApples: 3, tameTier: 2, mystical: true, wings: true, abilities: ['fly'], fleeSpeed: 4.2, followSpeed: 3.8 });
PonyKinds.register({ id: 'pony_unicorn', name: 'Unicorn', baseSpeed: 4.8, lassoTier: 3, ring: 3, weight: 2, group: [1, 2], levelBase: 16, tameApples: 4, tameTier: 3, mystical: true, horn: true });
PonyKinds.register({ id: 'pony_moon', name: 'Moon Pony', rarity: 'epic', baseSpeed: 5.0, lassoTier: 3, lassoNeeds: ['lasso_crystal'], ring: 0, weight: 0, group: [1, 1], levelBase: 14, tameApples: 4, tameTier: 3, mystical: true, horn: true, fleeSpeed: 4.4, followSpeed: 3.8 });     // weight 0: never in a herd; the night brings one now and then (nightEvents.js)
PonyKinds.register({ id: 'pony_alicorn', name: 'Alicorn', rarity: 'rare', baseSpeed: 5.6, lassoTier: 4, ring: 4, weight: 1.5, group: [1, 1], levelBase: 21, tameApples: 5, tameTier: 4, mystical: true, wings: true, horn: true, abilities: ['fly'], fleeSpeed: 4.4, followSpeed: 4.0 });
/* The SKY ponies: weight 0 (never in a herd); the sky brings one now and then (skyPonies.js). `rarity` is the lowest rarity one is born with (a stronger sky can make it better). */
PonyKinds.register({ id: 'pony_water', name: 'Water Pony', rarity: 'rare', baseSpeed: 4.8, lassoTier: 3, lassoNeeds: ['lasso_water'], ring: 0, weight: 0, group: [1, 1], levelBase: 12, tameApples: 4, tameTier: 3, mystical: true, fleeSpeed: 4.2, followSpeed: 3.8 });
PonyKinds.register({ id: 'pony_sun', name: 'Sun Pony', rarity: 'rare', baseSpeed: 5.2, lassoTier: 3, lassoNeeds: ['lasso_sun'], ring: 0, weight: 0, group: [1, 1], levelBase: 14, tameApples: 4, tameTier: 3, mystical: true, horn: true, fleeSpeed: 4.4, followSpeed: 3.8 });
PonyKinds.register({ id: 'pony_lightning', name: 'Lightning Pony', rarity: 'epic', baseSpeed: 5.8, lassoTier: 4, lassoNeeds: ['lasso_lightning'], ring: 0, weight: 0, group: [1, 1], levelBase: 17, tameApples: 5, tameTier: 4, mystical: true, wings: true, abilities: ['fly'], fleeSpeed: 5.0, followSpeed: 4.0 });
PonyKinds.register({ id: 'pony_star', name: 'Star Pony', rarity: 'legendary', baseSpeed: 5.8, lassoTier: 4, lassoNeeds: ['lasso_harmony'], ring: 0, weight: 0, group: [1, 1], levelBase: 22, tameApples: 6, tameTier: 4, mystical: true, wings: true, horn: true, abilities: ['fly'], fleeSpeed: 5.0, followSpeed: 4.0 });

